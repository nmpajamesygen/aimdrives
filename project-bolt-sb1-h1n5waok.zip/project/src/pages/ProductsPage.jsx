import React, { useState } from 'react'
import { motion } from 'framer-motion'
import ProductCard from '../components/ui/ProductCard'

const ProductsPage = () => {
  const [activeCategory, setActiveCategory] = useState('all')
  
  const categories = [
    { id: 'all', name: 'All Products' },
    { id: 'subscription', name: 'Subscriptions' },
    { id: 'oneTime', name: 'One-Time Purchases' },
    { id: 'accessories', name: 'Accessories' }
  ]
  
  const products = [
    {
      id: 1,
      name: 'AG1 Monthly Subscription',
      description: 'One daily scoop delivers comprehensive nutrition to fill the gaps in your diet.',
      price: 79,
      category: 'subscription',
      image: 'https://images.pexels.com/photos/4464821/pexels-photo-4464821.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
      popular: true,
      features: ['Monthly delivery', 'Free shipping', 'Cancel anytime']
    },
    {
      id: 2,
      name: 'AG1 Quarterly Subscription',
      description: 'Save more with our quarterly plan. Perfect for regular users.',
      price: 227,
      category: 'subscription',
      image: 'https://images.pexels.com/photos/7290737/pexels-photo-7290737.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
      popular: false,
      features: ['Every 3 months', 'Save 5%', 'Free shipping', 'Cancel anytime']
    },
    {
      id: 3,
      name: 'AG1 Single Purchase',
      description: 'Try AG1 without commitment. One-time purchase of our signature formula.',
      price: 99,
      category: 'oneTime',
      image: 'https://images.pexels.com/photos/4464848/pexels-photo-4464848.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
      popular: false,
      features: ['One-time purchase', 'Free shipping', 'No subscription']
    },
    {
      id: 4,
      name: 'AG1 Travel Packs',
      description: 'Individual servings perfect for travel and on-the-go nutrition.',
      price: 109,
      category: 'oneTime',
      image: 'https://images.pexels.com/photos/7290720/pexels-photo-7290720.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
      popular: false,
      features: ['30 individual packets', 'Perfect for travel', 'One-time purchase']
    },
    {
      id: 5,
      name: 'AG1 Shaker Bottle',
      description: 'Our premium shaker bottle for the perfect AG1 mix every time.',
      price: 19,
      category: 'accessories',
      image: 'https://images.pexels.com/photos/6551174/pexels-photo-6551174.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
      popular: false,
      features: ['BPA-free plastic', '20oz capacity', 'Leak-proof design']
    },
    {
      id: 6,
      name: 'AG1 Insulated Bottle',
      description: 'Keep your AG1 cold for hours with our premium insulated bottle.',
      price: 29,
      category: 'accessories',
      image: 'https://images.pexels.com/photos/1188649/pexels-photo-1188649.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
      popular: false,
      features: ['Stainless steel', 'Double-wall insulation', '24oz capacity']
    }
  ]

  const filteredProducts = activeCategory === 'all' 
    ? products 
    : products.filter(product => product.category === activeCategory)

  const fadeInUpVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 }
    }
  }

  const staggerContainerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  }

  const tabVariants = {
    active: {
      color: '#001D13',
      fontWeight: 600,
      borderColor: '#88BD4A',
      transition: { duration: 0.3 }
    },
    inactive: {
      color: '#6B7280',
      fontWeight: 400,
      borderColor: 'transparent',
      transition: { duration: 0.3 }
    }
  }

  return (
    <div>
      {/* Hero Section */}
      <section className="py-20 md:py-32 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h1 
              className="text-4xl md:text-5xl font-bold text-primary mb-6"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              Our Products
            </motion.h1>
            <motion.p 
              className="text-xl text-gray-600 mb-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              Discover our range of products designed to support your health journey.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center mb-12 border-b border-gray-200">
            {categories.map((category) => (
              <motion.button
                key={category.id}
                className={`px-6 py-4 text-center ${
                  activeCategory === category.id ? 'border-b-2' : 'border-b-2 border-transparent'
                }`}
                onClick={() => setActiveCategory(category.id)}
                variants={tabVariants}
                animate={activeCategory === category.id ? 'active' : 'inactive'}
              >
                {category.name}
              </motion.button>
            ))}
          </div>

          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            key={activeCategory}
            variants={staggerContainerVariants}
            initial="hidden"
            animate="visible"
          >
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </motion.div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <motion.h2 
              className="text-3xl font-bold text-primary mb-6"
              variants={fadeInUpVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              Why Choose AG1 Products
            </motion.h2>
            <motion.p 
              className="text-lg text-gray-600 max-w-2xl mx-auto"
              variants={fadeInUpVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              Our products are designed with your health in mind, using only the highest quality ingredients.
            </motion.p>
          </div>

          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
            variants={staggerContainerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.div 
              className="bg-white p-8 rounded-lg shadow-sm text-center"
              variants={fadeInUpVariants}
            >
              <div className="w-16 h-16 mx-auto bg-secondary rounded-full flex items-center justify-center mb-6">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-primary mb-4">Premium Quality</h3>
              <p className="text-gray-600">
                We source only the highest quality ingredients for optimal nutrition and bioavailability.
              </p>
            </motion.div>

            <motion.div 
              className="bg-white p-8 rounded-lg shadow-sm text-center"
              variants={fadeInUpVariants}
            >
              <div className="w-16 h-16 mx-auto bg-secondary rounded-full flex items-center justify-center mb-6">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-primary mb-4">Personalized Support</h3>
              <p className="text-gray-600">
                Our team of nutrition experts is available to help you optimize your AG1 experience.
              </p>
            </motion.div>

            <motion.div 
              className="bg-white p-8 rounded-lg shadow-sm text-center"
              variants={fadeInUpVariants}
            >
              <div className="w-16 h-16 mx-auto bg-secondary rounded-full flex items-center justify-center mb-6">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-primary mb-4">Flexible Delivery</h3>
              <p className="text-gray-600">
                Choose between one-time purchases or convenient subscriptions that fit your lifestyle.
              </p>
            </motion.div>

            <motion.div 
              className="bg-white p-8 rounded-lg shadow-sm text-center"
              variants={fadeInUpVariants}
            >
              <div className="w-16 h-16 mx-auto bg-secondary rounded-full flex items-center justify-center mb-6">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-primary mb-4">Satisfaction Guarantee</h3>
              <p className="text-gray-600">
                We stand behind our products with a 100% satisfaction guarantee for your peace of mind.
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <motion.h2 
              className="text-3xl font-bold text-primary mb-6"
              variants={fadeInUpVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              Frequently Asked Questions
            </motion.h2>
            <motion.p 
              className="text-lg text-gray-600 max-w-2xl mx-auto"
              variants={fadeInUpVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              Find answers to common questions about our products.
            </motion.p>
          </div>

          <div className="max-w-3xl mx-auto">
            <motion.div 
              className="mb-6"
              variants={fadeInUpVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              <h3 className="text-xl font-bold text-primary mb-2">How do I take AG1?</h3>
              <p className="text-gray-600">
                Simply mix one scoop with 8-12 oz of cold water and drink it first thing in the morning on an empty stomach for optimal absorption.
              </p>
            </motion.div>

            <motion.div 
              className="mb-6"
              variants={fadeInUpVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              <h3 className="text-xl font-bold text-primary mb-2">Can I cancel my subscription anytime?</h3>
              <p className="text-gray-600">
                Yes, you can easily pause, skip, or cancel your subscription at any time through your account or by contacting our customer service team.
              </p>
            </motion.div>

            <motion.div 
              className="mb-6"
              variants={fadeInUpVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              <h3 className="text-xl font-bold text-primary mb-2">How long does each pouch last?</h3>
              <p className="text-gray-600">
                Each pouch contains 30 servings, which is a one-month supply when taken daily as recommended.
              </p>
            </motion.div>

            <motion.div 
              className="mb-6"
              variants={fadeInUpVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              <h3 className="text-xl font-bold text-primary mb-2">Is AG1 suitable for vegans?</h3>
              <p className="text-gray-600">
                Yes, AG1 is vegan-friendly and contains no animal-derived ingredients. It's also gluten-free, dairy-free, and contains no artificial colors or flavors.
              </p>
            </motion.div>

            <motion.div 
              variants={fadeInUpVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              <h3 className="text-xl font-bold text-primary mb-2">How soon will I notice results?</h3>
              <p className="text-gray-600">
                Many customers report feeling improvements in energy and digestion within the first week. For more comprehensive benefits, we recommend consistent use for at least 30 days.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <motion.h2 
            className="text-3xl md:text-4xl font-bold mb-6"
            variants={fadeInUpVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            Ready to Transform Your Health?
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto"
            variants={fadeInUpVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            Join thousands of satisfied customers who've made AG1 a part of their daily routine.
          </motion.p>
          <motion.a
            href="#shop-now"
            className="btn bg-white text-primary hover:bg-gray-100"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            variants={fadeInUpVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            Shop Now
          </motion.a>
        </div>
      </section>
    </div>
  )
}

export default ProductsPage