import React from 'react'
import { motion } from 'framer-motion'

const AboutPage = () => {
  const teamMembers = [
    {
      name: 'Dr. Sarah Richards',
      title: 'Chief Scientific Officer',
      image: 'https://randomuser.me/api/portraits/women/22.jpg',
      bio: 'Dr. Richards leads our research and development team with over 15 years of experience in nutritional science.'
    },
    {
      name: 'Michael Tanner',
      title: 'Founder & CEO',
      image: 'https://randomuser.me/api/portraits/men/32.jpg',
      bio: 'Michael founded AG1 after his personal health journey led him to discover the power of comprehensive nutrition.'
    },
    {
      name: 'Dr. James Wong',
      title: 'Nutrition Director',
      image: 'https://randomuser.me/api/portraits/men/52.jpg',
      bio: 'Dr. Wong ensures that our formulations meet the highest standards of nutritional excellence and efficacy.'
    },
    {
      name: 'Emily Larson',
      title: 'Chief Operations Officer',
      image: 'https://randomuser.me/api/portraits/women/44.jpg',
      bio: 'Emily oversees our sustainable supply chain and ensures that AG1 is produced with the utmost quality and care.'
    }
  ]

  const fadeInUpVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 }
    }
  }

  const staggerContainerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  }

  return (
    <div>
      {/* Hero Section */}
      <section className="py-20 md:py-32 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <motion.h1 
              className="text-4xl md:text-5xl font-bold text-primary mb-6"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              Our Story
            </motion.h1>
            <motion.p 
              className="text-xl text-gray-600 mb-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              AG1 was born from a simple idea: comprehensive nutrition shouldn't be complicated.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <motion.div 
              className="md:w-1/2 mb-10 md:mb-0 md:pr-12"
              variants={fadeInUpVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold text-primary mb-6">Our Mission</h2>
              <p className="text-lg text-gray-600 mb-6">
                At AG1, we believe that optimal health starts with proper nutrition. Our mission is to make comprehensive nutrition accessible to everyone through our science-backed, whole food-based supplements.
              </p>
              <p className="text-lg text-gray-600">
                We're committed to creating products that support your body's natural functions, using the highest quality ingredients sourced directly from nature.
              </p>
            </motion.div>
            <motion.div 
              className="md:w-1/2"
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <img 
                src="https://images.pexels.com/photos/3735219/pexels-photo-3735219.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                alt="Our mission" 
                className="rounded-lg shadow-xl"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <motion.h2 
              className="text-3xl font-bold text-primary mb-6"
              variants={fadeInUpVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              Our Core Values
            </motion.h2>
            <motion.p 
              className="text-lg text-gray-600 max-w-2xl mx-auto"
              variants={fadeInUpVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              These principles guide everything we do at AG1, from product development to customer service.
            </motion.p>
          </div>

          <motion.div 
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
            variants={staggerContainerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            <motion.div 
              className="bg-white p-8 rounded-lg shadow-sm"
              variants={fadeInUpVariants}
            >
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mb-6">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-primary mb-4">Quality First</h3>
              <p className="text-gray-600">
                We never compromise on the quality of our ingredients. Every batch is tested for purity and potency to ensure you're getting the very best.
              </p>
            </motion.div>

            <motion.div 
              className="bg-white p-8 rounded-lg shadow-sm"
              variants={fadeInUpVariants}
            >
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mb-6">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-primary mb-4">Science-Backed</h3>
              <p className="text-gray-600">
                Our formulations are based on scientific research and developed by a team of nutrition experts and doctors to ensure efficacy.
              </p>
            </motion.div>

            <motion.div 
              className="bg-white p-8 rounded-lg shadow-sm"
              variants={fadeInUpVariants}
            >
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mb-6">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-primary mb-4">Sustainability</h3>
              <p className="text-gray-600">
                We're committed to environmentally responsible practices, from ingredient sourcing to packaging, minimizing our ecological footprint.
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <motion.h2 
              className="text-3xl font-bold text-primary mb-6"
              variants={fadeInUpVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              Meet Our Team
            </motion.h2>
            <motion.p 
              className="text-lg text-gray-600 max-w-2xl mx-auto"
              variants={fadeInUpVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              The passionate experts behind AG1 who are dedicated to revolutionizing health through nutrition.
            </motion.p>
          </div>

          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
            variants={staggerContainerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            {teamMembers.map((member, index) => (
              <motion.div 
                key={index}
                className="text-center"
                variants={fadeInUpVariants}
              >
                <div className="mb-4 relative">
                  <img 
                    src={member.image} 
                    alt={member.name} 
                    className="w-40 h-40 rounded-full mx-auto object-cover"
                  />
                  <div className="absolute inset-0 rounded-full bg-secondary bg-opacity-20 transform hover:scale-110 transition-transform duration-300"></div>
                </div>
                <h3 className="text-xl font-bold text-primary">{member.name}</h3>
                <p className="text-secondary font-medium mb-2">{member.title}</p>
                <p className="text-gray-600 px-4">{member.bio}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <motion.h2 
            className="text-3xl md:text-4xl font-bold mb-6"
            variants={fadeInUpVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            Join Our Mission for Better Health
          </motion.h2>
          <motion.p 
            className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto"
            variants={fadeInUpVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            Be part of the community that's transforming their health with just one daily scoop of AG1.
          </motion.p>
          <motion.a
            href="#shop-now"
            className="btn bg-white text-primary hover:bg-gray-100"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            variants={fadeInUpVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
          >
            Try AG1 Today
          </motion.a>
        </div>
      </section>
    </div>
  )
}

export default AboutPage