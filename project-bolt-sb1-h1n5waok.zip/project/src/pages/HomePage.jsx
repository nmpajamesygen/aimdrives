import React from 'react'
import { motion } from 'framer-motion'
import HeroSection from '../components/sections/HeroSection'
import FeaturesSection from '../components/sections/FeaturesSection'
import ProductsSection from '../components/sections/ProductsSection'
import TestimonialsSection from '../components/sections/TestimonialsSection'
import IngredientsSection from '../components/sections/IngredientsSection'
import CtaSection from '../components/sections/CtaSection'
import InstagramFeed from '../components/sections/InstagramFeed'

const HomePage = () => {
  return (
    <div>
      <HeroSection />
      <FeaturesSection />
      <ProductsSection />
      <TestimonialsSection />
      <IngredientsSection />
      <CtaSection />
      <InstagramFeed />
    </div>
  )
}

export default HomePage