import React from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'

const MobileMenu = ({ isOpen, onClose }) => {
  const menuVariants = {
    closed: {
      opacity: 0,
      x: '100%',
      transition: {
        duration: 0.3,
        ease: 'easeInOut'
      }
    },
    open: {
      opacity: 1,
      x: 0,
      transition: {
        duration: 0.3,
        ease: 'easeInOut'
      }
    }
  }

  const linkVariants = {
    closed: { y: 20, opacity: 0 },
    open: i => ({
      y: 0,
      opacity: 1,
      transition: {
        delay: 0.1 + i * 0.1,
        duration: 0.3
      }
    })
  }

  const menuItems = [
    { text: 'Home', path: '/' },
    { text: 'Products', path: '/products' },
    { text: 'About', path: '/about' },
    { text: 'Contact', path: '/contact' }
  ]

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 bg-white z-40 flex flex-col pt-24 px-6"
          initial="closed"
          animate="open"
          exit="closed"
          variants={menuVariants}
        >
          <nav className="flex flex-col space-y-6 text-xl">
            {menuItems.map((item, i) => (
              <motion.div
                key={item.text}
                custom={i}
                variants={linkVariants}
                initial="closed"
                animate="open"
                exit="closed"
              >
                <Link 
                  to={item.path} 
                  className="text-primary hover:text-secondary block py-2 border-b border-gray-200"
                  onClick={onClose}
                >
                  {item.text}
                </Link>
              </motion.div>
            ))}
            <motion.div
              custom={menuItems.length}
              variants={linkVariants}
              initial="closed"
              animate="open"
              exit="closed"
              className="pt-4"
            >
              <a 
                href="#shop-now" 
                className="btn btn-primary w-full text-center" 
                onClick={onClose}
              >
                Shop Now
              </a>
            </motion.div>
          </nav>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export default MobileMenu