import React from 'react'
import { motion } from 'framer-motion'
import Slider from 'react-slick'
import 'slick-carousel/slick/slick.css'
import 'slick-carousel/slick/slick-theme.css'

const TestimonialsSection = () => {
  const testimonials = [
    {
      id: 1,
      name: 'Sarah Johnson',
      title: 'Fitness Instructor',
      image: 'https://randomuser.me/api/portraits/women/44.jpg',
      quote: 'AG1 has completely transformed my morning routine. I feel more energized, focused, and my digestion has improved significantly.',
      rating: 5
    },
    {
      id: 2,
      name: 'Michael Chen',
      title: 'Software Engineer',
      image: 'https://randomuser.me/api/portraits/men/67.jpg',
      quote: 'As someone who sits at a desk all day, I needed something to boost my nutrition. AG1 was the perfect solution - easy, tasty, and effective.',
      rating: 5
    },
    {
      id: 3,
      name: 'Jessica Williams',
      title: 'Busy Mom of Three',
      image: 'https://randomuser.me/api/portraits/women/63.jpg',
      quote: 'With three kids, I rarely have time to prepare nutritious meals. AG1 ensures I get essential nutrients even on the busiest days.',
      rating: 4
    },
    {
      id: 4,
      name: 'David Rodriguez',
      title: 'Professional Athlete',
      image: 'https://randomuser.me/api/portraits/men/94.jpg',
      quote: 'I\'ve tried many supplements throughout my career, but AG1 stands out for its quality and the way it supports my recovery and performance.',
      rating: 5
    }
  ]

  const sliderSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 2,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 5000,
    pauseOnHover: true,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  }

  const renderStars = (rating) => {
    return Array(5).fill(0).map((_, index) => (
      <svg
        key={index}
        className={`w-5 h-5 ${index < rating ? 'text-yellow-400' : 'text-gray-300'}`}
        fill="currentColor"
        viewBox="0 0 20 20"
      >
        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
      </svg>
    ))
  }

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">What Our Customers Say</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Thousands of people have transformed their health with AG1. Here's what some of them have to say.
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
        >
          <Slider {...sliderSettings} className="testimonial-slider">
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="px-4">
                <div className="bg-gray-50 p-8 rounded-lg shadow-sm h-full">
                  <div className="flex items-center mb-4">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-14 h-14 rounded-full mr-4"
                    />
                    <div>
                      <h4 className="font-bold text-primary">{testimonial.name}</h4>
                      <p className="text-gray-500 text-sm">{testimonial.title}</p>
                    </div>
                  </div>
                  <div className="flex mb-4">
                    {renderStars(testimonial.rating)}
                  </div>
                  <p className="text-gray-600 italic">"{testimonial.quote}"</p>
                </div>
              </div>
            ))}
          </Slider>
        </motion.div>

        <div className="mt-12 text-center">
          <a href="#" className="text-secondary font-semibold hover:underline inline-flex items-center">
            Read More Reviews
            <svg 
              className="ml-2 w-4 h-4" 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M14 5l7 7m0 0l-7 7m7-7H3" 
              />
            </svg>
          </a>
        </div>
      </div>
    </section>
  )
}

export default TestimonialsSection