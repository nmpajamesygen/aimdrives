import React from 'react'
import { motion } from 'framer-motion'

const CtaSection = () => {
  return (
    <section className="py-20 bg-primary text-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Transform Your Health?</h2>
              <p className="text-lg text-gray-300 mb-8">
                Join thousands of customers who have made AG1 a part of their daily health routine. One scoop, once a day, for better health.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <motion.a
                  href="#shop-now"
                  className="btn bg-secondary text-white hover:bg-opacity-90 text-center"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Start Your Journey
                </motion.a>
                <motion.a
                  href="#learn-more"
                  className="btn border border-white text-white hover:bg-white hover:text-primary text-center"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Learn More
                </motion.a>
              </div>
            </motion.div>
          </div>
          
          <div className="md:w-1/2">
            <motion.div
              className="bg-white text-primary p-8 rounded-lg shadow-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold">Subscribe & Save</h3>
                <span className="bg-secondary text-white text-sm font-semibold px-3 py-1 rounded-full">
                  20% OFF
                </span>
              </div>
              
              <ul className="mb-6 space-y-3">
                <li className="flex items-center">
                  <svg 
                    className="w-5 h-5 text-secondary mr-2" 
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24" 
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      strokeWidth={2} 
                      d="M5 13l4 4L19 7" 
                    />
                  </svg>
                  <span>Monthly delivery at your doorstep</span>
                </li>
                <li className="flex items-center">
                  <svg 
                    className="w-5 h-5 text-secondary mr-2" 
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24" 
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      strokeWidth={2} 
                      d="M5 13l4 4L19 7" 
                    />
                  </svg>
                  <span>Free shipping on all orders</span>
                </li>
                <li className="flex items-center">
                  <svg 
                    className="w-5 h-5 text-secondary mr-2" 
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24" 
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      strokeWidth={2} 
                      d="M5 13l4 4L19 7" 
                    />
                  </svg>
                  <span>Exclusive access to nutritional coaching</span>
                </li>
                <li className="flex items-center">
                  <svg 
                    className="w-5 h-5 text-secondary mr-2" 
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24" 
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      strokeWidth={2} 
                      d="M5 13l4 4L19 7" 
                    />
                  </svg>
                  <span>Cancel or pause anytime</span>
                </li>
              </ul>
              
              <div className="flex items-baseline mb-6">
                <span className="text-3xl font-bold">$79</span>
                <span className="ml-2 text-gray-500">/month</span>
                <span className="ml-3 text-sm line-through text-gray-500">$99</span>
              </div>
              
              <motion.button
                className="w-full btn bg-primary text-white hover:bg-opacity-90"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Subscribe Now
              </motion.button>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default CtaSection