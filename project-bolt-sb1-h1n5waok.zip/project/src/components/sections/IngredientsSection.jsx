import React, { useState } from 'react'
import { motion } from 'framer-motion'

const IngredientsSection = () => {
  const [activeCategory, setActiveCategory] = useState('vitamins')
  
  const categories = [
    { id: 'vitamins', name: 'Vitamins & Minerals' },
    { id: 'probiotics', name: 'Probiotics' },
    { id: 'adaptogens', name: 'Adaptogens' },
    { id: 'greens', name: 'Greens & Superfoods' }
  ]
  
  const ingredients = {
    vitamins: [
      { name: 'Vitamin A', benefit: 'Supports vision and immune function' },
      { name: 'Vitamin C', benefit: 'Powerful antioxidant for immune support' },
      { name: 'Vitamin D3', benefit: 'Supports bone health and immune function' },
      { name: 'Vitamin E', benefit: 'Antioxidant that protects cells from damage' },
      { name: 'B-Complex Vitamins', benefit: 'Support energy production and metabolism' },
      { name: 'Zinc', benefit: 'Supports immune function and protein synthesis' },
      { name: 'Magnesium', benefit: 'Supports muscle and nerve function' },
      { name: 'Selenium', benefit: 'Supports antioxidant function and thyroid health' }
    ],
    probiotics: [
      { name: 'Lactobacillus acidophilus', benefit: 'Supports digestive and immune health' },
      { name: 'Bifidobacterium bifidum', benefit: 'Supports gut barrier function' },
      { name: 'Lactobacillus rhamnosus', benefit: 'Supports gut health and immunity' },
      { name: 'Bifidobacterium lactis', benefit: 'Supports digestive balance' }
    ],
    adaptogens: [
      { name: 'Ashwagandha', benefit: 'Helps the body adapt to stress' },
      { name: 'Rhodiola Rosea', benefit: 'Supports mental performance during stress' },
      { name: 'Reishi Mushroom', benefit: 'Supports immune function and stress response' },
      { name: 'Holy Basil', benefit: 'Helps maintain mental clarity and calmness' }
    ],
    greens: [
      { name: 'Spirulina', benefit: 'Nutrient-dense blue-green algae' },
      { name: 'Chlorella', benefit: 'Supports detoxification processes' },
      { name: 'Wheatgrass', benefit: 'Rich in chlorophyll and antioxidants' },
      { name: 'Moringa Leaf', benefit: 'Provides essential amino acids and nutrients' },
      { name: 'Kale', benefit: 'Rich in vitamins K, A, and C' },
      { name: 'Spinach', benefit: 'Source of iron and antioxidants' }
    ]
  }

  const tabVariants = {
    active: {
      color: '#001D13',
      fontWeight: 600,
      borderColor: '#88BD4A',
      transition: { duration: 0.3 }
    },
    inactive: {
      color: '#6B7280',
      fontWeight: 400,
      borderColor: 'transparent',
      transition: { duration: 0.3 }
    }
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05
      }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, x: -10 },
    visible: {
      opacity: 1,
      x: 0,
      transition: { duration: 0.3 }
    }
  }

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">What's Inside</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            AG1 contains 75+ high-quality ingredients carefully selected to support your health.
          </p>
        </div>

        <div className="flex flex-wrap justify-center mb-12 border-b border-gray-200">
          {categories.map((category) => (
            <motion.button
              key={category.id}
              className={`px-6 py-4 text-center ${
                activeCategory === category.id ? 'border-b-2' : 'border-b-2 border-transparent'
              }`}
              onClick={() => setActiveCategory(category.id)}
              variants={tabVariants}
              animate={activeCategory === category.id ? 'active' : 'inactive'}
            >
              {category.name}
            </motion.button>
          ))}
        </div>

        <motion.ul
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          key={activeCategory}
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {ingredients[activeCategory].map((ingredient, index) => (
            <motion.li
              key={index}
              className="bg-white p-4 rounded-lg shadow-sm"
              variants={itemVariants}
            >
              <h4 className="font-semibold text-primary mb-1">{ingredient.name}</h4>
              <p className="text-sm text-gray-600">{ingredient.benefit}</p>
            </motion.li>
          ))}
        </motion.ul>

        <div className="mt-12 text-center">
          <motion.a
            href="#"
            className="text-secondary font-semibold hover:underline inline-flex items-center"
            whileHover={{ scale: 1.05 }}
          >
            View Full Ingredients List
            <svg 
              className="ml-2 w-4 h-4" 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M14 5l7 7m0 0l-7 7m7-7H3" 
              />
            </svg>
          </motion.a>
        </div>
      </div>
    </section>
  )
}

export default IngredientsSection