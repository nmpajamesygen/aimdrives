import React, { useState } from 'react'
import { motion } from 'framer-motion'
import ProductCard from '../ui/ProductCard'

const ProductsSection = () => {
  const [activeTab, setActiveTab] = useState('subscription')
  
  const products = {
    subscription: [
      {
        id: 1,
        name: 'AG1 Monthly Subscription',
        description: 'One daily scoop delivers comprehensive nutrition to fill the gaps in your diet.',
        price: 79,
        image: 'https://images.pexels.com/photos/4464821/pexels-photo-4464821.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
        popular: true,
        features: ['Monthly delivery', 'Free shipping', 'Cancel anytime']
      },
      {
        id: 2,
        name: 'AG1 Quarterly Subscription',
        description: 'Save more with our quarterly plan. Perfect for regular users.',
        price: 227,
        image: 'https://images.pexels.com/photos/7290737/pexels-photo-7290737.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
        popular: false,
        features: ['Every 3 months', 'Save 5%', 'Free shipping', 'Cancel anytime']
      }
    ],
    oneTime: [
      {
        id: 3,
        name: 'AG1 Single Purchase',
        description: 'Try AG1 without commitment. One-time purchase of our signature formula.',
        price: 99,
        image: 'https://images.pexels.com/photos/4464848/pexels-photo-4464848.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
        popular: false,
        features: ['One-time purchase', 'Free shipping', 'No subscription']
      },
      {
        id: 4,
        name: 'AG1 Travel Packs',
        description: 'Individual servings perfect for travel and on-the-go nutrition.',
        price: 109,
        image: 'https://images.pexels.com/photos/7290720/pexels-photo-7290720.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
        popular: false,
        features: ['30 individual packets', 'Perfect for travel', 'One-time purchase']
      }
    ]
  }

  const tabVariants = {
    active: {
      borderColor: '#88BD4A',
      color: '#001D13',
      fontWeight: 600,
      transition: { duration: 0.3 }
    },
    inactive: {
      borderColor: 'transparent',
      color: '#6B7280',
      fontWeight: 400,
      transition: { duration: 0.3 }
    }
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  }

  return (
    <section className="py-20 bg-gray-50" id="shop-now">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">Choose Your Plan</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Select the option that works best for your lifestyle and goals.
          </p>
        </div>

        <div className="flex justify-center mb-12">
          <div className="inline-flex rounded-md border border-gray-200 p-1 bg-white">
            <motion.button
              className={`px-6 py-2 rounded-md text-sm sm:text-base ${activeTab === 'subscription' ? 'bg-gray-100' : ''}`}
              onClick={() => setActiveTab('subscription')}
              variants={tabVariants}
              animate={activeTab === 'subscription' ? 'active' : 'inactive'}
            >
              Subscription
            </motion.button>
            <motion.button
              className={`px-6 py-2 rounded-md text-sm sm:text-base ${activeTab === 'oneTime' ? 'bg-gray-100' : ''}`}
              onClick={() => setActiveTab('oneTime')}
              variants={tabVariants}
              animate={activeTab === 'oneTime' ? 'active' : 'inactive'}
            >
              One-Time Purchase
            </motion.button>
          </div>
        </div>

        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
          key={activeTab}
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {products[activeTab].map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </motion.div>
      </div>
    </section>
  )
}

export default ProductsSection