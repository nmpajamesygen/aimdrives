import React from 'react'

const Logo = ({ variant = 'dark' }) => {
  const textColor = variant === 'light' ? 'text-white' : 'text-primary'
  
  return (
    <div className={`flex items-center ${textColor} font-bold text-2xl`}>
      <span className="text-secondary mr-1">AG</span>1
    </div>
  )
}

export default Logo