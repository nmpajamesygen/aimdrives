import React from 'react'
import { motion } from 'framer-motion'

const ProductCard = ({ product }) => {
  const { name, description, price, image, popular, features } = product

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 }
    }
  }

  return (
    <motion.div
      className={`bg-white rounded-xl overflow-hidden shadow-lg ${popular ? 'border-2 border-secondary' : 'border border-gray-200'}`}
      variants={cardVariants}
    >
      <div className="relative">
        <img 
          src={image} 
          alt={name} 
          className="w-full h-64 object-cover"
        />
        {popular && (
          <div className="absolute top-4 right-4 bg-secondary text-white text-sm font-semibold px-3 py-1 rounded-full">
            Most Popular
          </div>
        )}
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-bold text-primary mb-2">{name}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        
        <div className="flex items-baseline mb-6">
          <span className="text-3xl font-bold text-primary">${price}</span>
          {product.id === 1 && (
            <span className="ml-2 text-gray-500">/month</span>
          )}
          {product.id === 2 && (
            <span className="ml-2 text-gray-500">/quarter</span>
          )}
        </div>
        
        <ul className="mb-6 space-y-2">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center text-gray-600">
              <svg 
                className="w-5 h-5 text-secondary mr-2" 
                fill="none" 
                stroke="currentColor" 
                viewBox="0 0 24 24" 
                xmlns="http://www.w3.org/2000/svg"
              >
                <path 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth={2} 
                  d="M5 13l4 4L19 7" 
                />
              </svg>
              {feature}
            </li>
          ))}
        </ul>
        
        <motion.button
          className="w-full btn btn-primary"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          Add to Cart
        </motion.button>
      </div>
    </motion.div>
  )
}

export default ProductCard